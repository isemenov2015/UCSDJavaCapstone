/**
 * @author Ilya Semenov
 * 
 * Main Graph implementation for the UCSD Java data structures Capstone project
 * 15.04.2016
 * Version 1.0
 *
 * 
 */
package graph;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Set;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.PriorityQueue;
import java.util.Queue;

//import util.GraphLoader;

public class CapGraph implements Graph {
    
    private HashMap<Integer, GraphNode> nodes;
    private HashMap<Integer, HashSet<Integer>> edges;
    private HashSet<GraphNode> contaminatedNodes;
    private static final int IMMUNITY_DAYS = 40; // Immunity period
    private static final double IMMUNITY_PROB = 0.9; // probability of contamination foul by contact while being immune
    private static final double CONTAMINATION_PROB = 0.03; // probability of virus contamination during the contact
    private static final int MIN_ILL_DAYS = 5;
    private static final int MAX_ILL_DAYS = 12;
    private static final int MAX_CONTACTS_INIT = 25;
    private static final int MAX_CONTACTS_AFTER_X_DAYS = 5;
    private static final int X_DAYS = 3;
	private static final float VACCINATION_RATE = (float) 0.70; // Must be in 0..1 interval

    public CapGraph() {
    	// constructor
        nodes = new HashMap<Integer, GraphNode>();
        edges = new HashMap<Integer, HashSet<Integer>>();
        contaminatedNodes = new HashSet<GraphNode>();
    }
    
    /* (non-Javadoc)
     * @see graph.Graph#addVertex(int)
     */
    @Override
    public void addVertex(int num) {
    // Adds new vertex to a graph
        
        if (!nodes.containsKey(num)) {
            GraphNode vertex = new GraphNode(num);
            nodes.put(num, vertex);
        }
    }

    /* (non-Javadoc)
     * @see graph.Graph#addEdge(int, int)
     */
    @Override
    public void addEdge(int from, int to) {
    // adds two opposite directed edges to ensure all edges are bidirectional
        addDirectEdge(from, to);
        addDirectEdge(to, from);
    }

    private void addDirectEdge(int from, int to) {
    	// adds directed edge to the graph
        if (nodes.containsKey(from) && nodes.containsKey(to)) {
            HashSet<Integer> nSet;
            if (edges.get(from) != null) {
                nSet = edges.get(from);
            }
            else {
                nSet = new HashSet<Integer>();
            }
            nSet.add(to);
            edges.put(from, nSet);
            //GraphNode node = nodes.get(from);
            //node.addChild(to);
        }
    }

    public void simulationTurn(int startNode) {
    	// implements one simulation turn based on BFS starting from given node
        if (!nodes.containsKey(startNode)) {
            // invalid node passed
            return;
        }
        Queue<Integer> nodeQueue = new PriorityQueue<Integer>();
        HashSet<Integer> visited = new HashSet<Integer>();
        HashMap<Integer, Integer> contactsCounter = new HashMap<Integer, Integer>();
        HashSet<Integer> queued = new HashSet<Integer>();
        int cNode;
        
        nodeQueue.add(startNode);
        queued.add(startNode);
        while (!nodeQueue.isEmpty()) {
            cNode = nodeQueue.poll();
            if (!visited.contains(cNode)) {
                //boolean nState = nodes.get(cNode).getIll();
                //System.out.println("Visited node No " + cNode + " ill state: " + nState);
                GraphNode procNode = nodes.get(cNode);
                if (procNode.getIll()) {
                    // node is ill
                    int illDays = procNode.getIllnessDuration() - procNode.getIllnessDays();
                    
                    // Neighbor contamination sequence
                    if (edges.containsKey(cNode)) {
                        ArrayList<Integer> neighborList = 
                                new ArrayList<Integer>(edges.get(cNode));
                        Collections.shuffle(neighborList, new Random());
                        int mContacts = (illDays > X_DAYS) ? MAX_CONTACTS_AFTER_X_DAYS :
                            MAX_CONTACTS_INIT;
                        for (int i = 0; i < Math.min(mContacts, neighborList.size()); i++) {
                            int nNode = neighborList.get(i);
                            if (!contactsCounter.containsKey(nNode)) {
                                contactsCounter.put(nNode, 0);
                            }
                            int contactsNum = contactsCounter.get(nNode);
                            if (contactsNum < MAX_CONTACTS_INIT) {
                                contaminateNode(nNode);
                                contactsCounter.put(nNode, contactsNum + 1);
                            }
                        }
                    }
                    
                    // process the node itself
                    if (procNode.getIllnessDays() <= 1) {
                        // last day of illness, need to set up immunity and apply healthy state
                        procNode.setIll(false);
                        procNode.setImmunityDays(IMMUNITY_DAYS);
                        procNode.setIllnessDuration(0);
                        contaminatedNodes.remove(procNode);
                    }
                    illDays = Math.max(0, procNode.getIllnessDays() - 1);
                    procNode.setIllnessDays(illDays);
                }
                else if (procNode.getIllnessDays() > 0) {
                    // node is ill for the first day
                    procNode.setIll(true);
                    procNode.setIllnessDuration( procNode.getIllnessDays() );
                    procNode.setImmunityDays(0);
                }
                else {
                    procNode.setImmunityDays(Math.max(0, procNode.getImmunityDays() - 1));
                }
                procNode.setSimDay(procNode.getSimDay() + 1);
                
            }
            
            if (edges.containsKey(cNode)) {
                for (int nd : edges.get(cNode)) {
                    if (!visited.contains(nd) && !queued.contains(nd)) {
                        nodeQueue.add(nd);
                        queued.add(nd);
                    }
                }
            }
            visited.add(cNode);
        }
    }
    
    private void contaminateNode(int node) {
    	// Marks node as ill with calculated probability
        double contProb = Math.random();
        double upLimit = CONTAMINATION_PROB;
        GraphNode gnd = nodes.get(node);
        
        if (!gnd.getIll()) {
            if (gnd.getImmunityDays() > 0) {
                upLimit *= 1 - IMMUNITY_PROB;
            }
            if (contProb < upLimit) {
                Random rndm = new Random();
                int illDays = MIN_ILL_DAYS + rndm.nextInt(MAX_ILL_DAYS - MIN_ILL_DAYS + 1);
                gnd.setIllnessDays(illDays);
                gnd.setIllnessDuration(illDays);
                contaminatedNodes.add(gnd);
            }
        }
    }
    
    public void makeIll(int node, int illnessDays) {
    	// Marks node as ill with probability 1.0
        if (!nodes.containsKey(node)) {
            throw new IllegalArgumentException("Invalid node number passed into makeIll method");
        }
        GraphNode gnd = nodes.get(node);
        gnd.setIll(true);
        gnd.setImmunityDays(0);
        gnd.setIllnessDays(illnessDays);
        gnd.setIllnessDuration(illnessDays);
        contaminatedNodes.add(gnd);
    }

    public HashSet<Integer> getNeighbors(int node) {
    	// Returns node neighbors set
        HashSet<Integer> neighbors = new HashSet<Integer>();
        if (edges.containsKey(node)) {
            neighbors = edges.get(node);
        }
        return neighbors;
    }
    
    
    /* (non-Javadoc)
     * @see graph.Graph#exportGraph()
     */
    @Override
    public HashMap<Integer, HashSet<Integer>> exportGraph() {
    	// necessary method for Graph type
    	
        HashMap<Integer, HashSet<Integer>> gr = new HashMap<Integer, HashSet<Integer>>();
        
        for (int node : nodes.keySet()) {
            HashSet<Integer> eSet = edges.get(node);
            gr.put(node, eSet);
        }
        return gr;
    }
    
    public void flush() {
    	// resets content for all nodes to default values
    	// also clears contaminated nodes set
    	for (int i : nodes.keySet()) {
    		GraphNode nd = new GraphNode(i);
    		nodes.put(i, nd);
    	}
    	contaminatedNodes.clear();
    }
    
    public void vaccinate(int period) {
    	// vaccinates all nodes in a graph with VACCINATION_RATE probability for a given period
    	Random rndm = new Random();
    	
    	for (GraphNode nnode : nodes.values()) {
    		if (rndm.nextFloat() < VACCINATION_RATE) {
    			nnode.setImmunityDays(period);
    		}
    	}
    }
    
    public String getParametersString() {
    	// Used to create output file header with key model parameters
        String rStr = "";
    	rStr += "IMMUNITY_DAYS = " + Integer.toString(IMMUNITY_DAYS); // Immunity period
        rStr += " IMMUNITY_PROB = " + Double.toString(IMMUNITY_PROB); // probability of reject contamination by contact while being immune
        rStr += " CONTAMINATION_PROB = " + Double.toString(CONTAMINATION_PROB); // probability of virus contamination during the contact
        rStr += " MIN_ILL_DAYS = " + Integer.toString(MIN_ILL_DAYS);
        rStr += " MAX_ILL_DAYS = " + Integer.toString(MAX_ILL_DAYS) + ";";
        rStr += " MAX_CONTACTS_INIT = " + Integer.toString(MAX_CONTACTS_INIT);
        rStr += " MAX_CONTACTS_AFTER_X_DAYS = " + Integer.toString(MAX_CONTACTS_AFTER_X_DAYS);
        rStr += " LATENT_PHASE_DAYS = " + Integer.toString(X_DAYS);
        rStr += " VACCINATION_RATE = " + Double.toString(VACCINATION_RATE);
        return rStr;
    }

	@Override
	public Graph getEgonet(int center) {
		// Stub for the method, not used in a simulation
		// Fully implemented and graded during warm up week
		return null;
	}

	@Override
	public List<Graph> getSCCs() {
		// Stub for the method, not used in a simulation
		// Fully implemented and graded during warm up week
		return null;
	}
    
    // Getters
    public HashSet<GraphNode> getContaminatedNodes() {
        return contaminatedNodes;
    }
    
    public int nodesQuantity() {
    	return nodes.size();
    }
    
    public Set<Integer> getNodesKeySet() {
    	return nodes.keySet();
    }
}

