/**
 * Very basic plotting class for visualizing epidemic waves
 * UCSD/Coursera Java data structures capstone.
 * 15.04.2016
 * Version 1.0
 */

package graph;

import java.awt.*;
import java.awt.geom.Line2D;
import java.util.ArrayList;

import javax.swing.*;

public class TrivialGraphic {
	private static final int cSize = 6;
	private static final int BOTTOMMARGIN = 60;
	private ArrayList<DrawPoint> dpoints = new ArrayList<DrawPoint>();
	private static final int plotWidth = 800;
	private static final int plotHeight = 600;
	private int nodesNumber = 0;
	private int simTurnsNumber = 0;
	
	public TrivialGraphic(int nNumber, int tNumber) {
		nodesNumber = nNumber;
		simTurnsNumber = tNumber;
	}
	
    @SuppressWarnings("serial")
	public void plotDots(String modelParams) {
    	// Main plotting procedure, creates a new window with plot

        JFrame jf = new JFrame("Common cold wave plot");
        Container cp = jf.getContentPane();
        cp.add(new JComponent() {
            public void paintComponent(Graphics g) {
                Graphics2D g2 = (Graphics2D) g;
                // We need to scale y coordinates since contaminations rate 
                // is almost always less than 50% population
                double scaler = 1.0;
                scaler = 1.0 * plotHeight / (nodesNumber * 0.7);
                
                g2.setColor(Color.RED);
                float epidemyLvlHeight = (float) 
                		(plotHeight - BOTTOMMARGIN - (6 * nodesNumber / 1000) * scaler);
                g2.draw(new Line2D.Float(0, epidemyLvlHeight, plotWidth, epidemyLvlHeight));
                g2.drawString("Epidemic wave level", plotWidth - 150, epidemyLvlHeight - 10);
                fillEmptyPoints();
                Color cl = new Color(0, 50, 220);
                // Wave plotting
                for (DrawPoint dpoint : dpoints) {
                	g2.setColor(cl);
                	g2.fillOval((plotWidth/dpoints.size()) * dpoint.getPoints()[0] + 10, 
                			(int)(plotHeight - BOTTOMMARGIN - 
                					Math.round(scaler * dpoint.getPoints()[1])), cSize, cSize);
                }
                g2.setColor(Color.BLACK);
                // draw coordinate axis
                g2.setStroke(new BasicStroke(2));
                g2.draw(new Line2D.Float(10, plotHeight - BOTTOMMARGIN + 5, 
                		plotWidth - 20, plotHeight - BOTTOMMARGIN + 5));
                g2.draw(new Line2D.Float(10, 10, 10, plotHeight - 30));
                // draw coordinates on both axis
                for (int i = 1; i < 8; i++) {
                	float thpoint = (float) (plotHeight - BOTTOMMARGIN - (i * 1000 * scaler));
                	g2.draw(new Line2D.Float(10, thpoint, 20, thpoint));
                	g2.drawString(Integer.toString(i * 1000), 25, thpoint);
                }
                for (int i = 1; i < 9; i++) {
                	float thpoint = (float) (plotWidth * i * 10/dpoints.size() + 10);
                	g2.draw(new Line2D.Float(thpoint, plotHeight - BOTTOMMARGIN + 5, 
                			thpoint, plotHeight - BOTTOMMARGIN + 10));
                	g2.drawString(Integer.toString(i * 10), 
                			plotWidth * i * 10/dpoints.size() + 10, plotHeight - BOTTOMMARGIN + 20);
                }
                String[] str = modelParams.split(";");
                g2.drawString(str[0], 35, 50);
                g2.drawString(str[1], 35, 70);
                g2.drawString("Day No", plotWidth - 100, plotHeight - 42);
                drawRotate(g2, 25, 80, 270, "Ill people No");
            }
        });
        jf.setSize(plotWidth, plotHeight);
        jf.setVisible(true);
    }
    
    public void AddDrawPoint(int xPoint, int yPoint) {
    	// Adds a point with its plot coordinates
    	DrawPoint dpoint = new DrawPoint(xPoint, yPoint);
    	dpoints.add(dpoint);
    }
    
    private void fillEmptyPoints() {
    	// Fills point array with dummy plot coordinates in case we have less than
    	// simTurnsNumber points to plot
    	for (int i = dpoints.size(); i < simTurnsNumber; i++) {
    		DrawPoint dummyPoint = new DrawPoint(Integer.MIN_VALUE, Integer.MIN_VALUE);
    		dpoints.add(dummyPoint);
    	}
    }
    
    public static void drawRotate(Graphics2D g2d, double x, double y, int angle, String text)
    // Rotates text to an arbitrary angle
    {    
        g2d.translate((float)x,(float)y);
        g2d.rotate(Math.toRadians(angle));
        g2d.drawString(text,0,0);
        g2d.rotate(-Math.toRadians(angle));
        g2d.translate(-(float)x,-(float)y);
    }    
}