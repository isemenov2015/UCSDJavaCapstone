/**
 * @author Ilya Semenov
 * 
 * Help class that contains sets of points to draw on a graphic
 * UCSD/Coursera Java data structures capstone.
 * 15.04.2016
 * Version 1.0
 */

package graph;

public class DrawPoint {
	private int xpoint;
	private int ypoint;
	
	DrawPoint(int x, int y) {
		xpoint = x;
		ypoint = y;
	}
	
	// getter
	public int[] getPoints() {
		int[] retarr = new int[3];
		retarr[0] = xpoint;
		retarr[1] = ypoint;
		return retarr;
	}
}
