/**
 * @author Ilya Semenov
 * 
 * Graph node class that represent a citizen in a common cold spread simulation. 
 * UCSD/Coursera Java data structures capstone.
 * 15.04.2016
 * Version 1.0
 *
 */

package graph;

public class GraphNode {
	private int nodeNum;
	//private HashSet<Integer> children;
	private boolean isIll;
	private int simDay;
	private int immunityDays;
	private int illnessDays;
	private int illnessDuration;
	
	public GraphNode(int vertex) {
		nodeNum = vertex;
		isIll = false;
		simDay = 0;
		immunityDays = 0;
		illnessDays = 0;
	}
	
	// getters and setters
	
	public int getVertex() {
		return this.nodeNum;
	}
	
	public boolean getIll() {
		return this.isIll;
	}
	
	public void setIll(boolean value) {
		this.isIll = value;
	}
	
	public int getSimDay() {
		return this.simDay;
	}
	
	public void setSimDay(int nDay) {
		this.simDay = nDay;
	}
	
	public int getImmunityDays() {
		return this.immunityDays;
	}
	
	public void setImmunityDays(int nDays) {
		this.immunityDays = nDays;
	}
	
	public int getIllnessDays() {
		return this.illnessDays;
	}
	
	public void setIllnessDays(int nDays) {
		this.illnessDays = nDays;
	}
	
	public int getIllnessDuration() {
	    return this.illnessDuration;
	}
	
	public void setIllnessDuration(int nDays) {
	    this.illnessDuration = nDays;
	}
}
