/**
 * @author Ilya Semenov
 * 
 * Loader class for common cold spread simulation. 
 * UCSD/Coursera Java data structures capstone.
 * 15.04.2016
 * Version 1.0
 *
 */

package graph;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Random;
import java.util.Set;

import util.GraphLoader;

public class Loader {
	private static final int NSIMULATIONS = 100;
	private static final int SIMTURNS = 100;

    public static void main(String[] args) throws FileNotFoundException, UnsupportedEncodingException {
        
       Graph graph = new CapGraph();
       GraphLoader.loadGraph(graph, "D:/11/UCSDCapstone/data/facebook_ucsd.txt");
       //neighborsDistribution((CapGraph)graph);
       //System.out.println("Graph loaded, " + ((CapGraph)graph).nodesQuantity() + " nodes loaded");
       HashSet<GraphNode> illSet = new HashSet<GraphNode>(); // Set of Nodes that were ill during simulation
       PrintWriter writer = new PrintWriter("output.txt", "UTF-8");
       writer.println("Model parameters: " + ((CapGraph) graph).getParametersString());
       writer.println("Turn No, starting node, contamination rate, " +
       					"max simultaneously ill, No of people that were ill more than once");
       TrivialGraphic tGr = new TrivialGraphic( ((CapGraph)graph).nodesQuantity(), SIMTURNS);
       for (int j = 0; j < NSIMULATIONS; ++j) {
    	   HashMap<GraphNode, Integer> contCounter = new HashMap<GraphNode, Integer>(); // contaminations No for each node counter
    	   ((CapGraph)graph).flush();
    	   
           int illNode = randomNode((CapGraph) graph);  // initial contaminated node
           ((CapGraph)graph).vaccinate(SIMTURNS); // apply vaccination procedure
           ((CapGraph)graph).makeIll(illNode, 10); // Initial node is always ill for 10 days
           illSet.clear();
           int maxIll = 1; // max simultaneously ill counter
    	   for (int i = 0; i < SIMTURNS; ++i) {
    		   @SuppressWarnings("unchecked")
    		   HashSet<GraphNode> contNodes = (HashSet<GraphNode>) 
										((CapGraph)graph).getContaminatedNodes().clone();
    		   int iNodes = contNodes.size();
    		   ((CapGraph)graph).simulationTurn(illNode);
//    		   System.out.println("Sim No " + j + " Total nodes infected after turn " + i + ": " + iNodes);
    		   contNodes.removeAll(((CapGraph)graph).getContaminatedNodes()); // get nodes that were contaminated this turn
    		   for (GraphNode freshCont : contNodes) {
    			   if (contCounter.containsKey(freshCont)) {
    				   contCounter.put(freshCont, contCounter.get(freshCont) + 1);
    			   }
    			   else {
    				   contCounter.put(freshCont, 1);
    			   }
    		   }
    		   illSet.addAll(((CapGraph)graph).getContaminatedNodes()); // update 
    		   if (iNodes > maxIll) {
    			   maxIll = iNodes;
    		   }
    		   if (iNodes == 0) {
    			   break;
    		   }
    		   if (j < 1) {
    			   tGr.AddDrawPoint(i, iNodes);
    		   }
    	   }
           System.out.println("Turn " + j + ", final contamination rate: " + 
	   				(double)illSet.size()/((CapGraph)graph).nodesQuantity());
           System.out.println("No of nodes, contaminated more than once: " + 
	   				countMultipleConts(contCounter));
           writer.println(j + ", " + illNode+ ", " + 
	   				(double)illSet.size()/((CapGraph)graph).nodesQuantity() + ", " + 
	   				maxIll + ", " + countMultipleConts(contCounter));
           if (j < 1) {
        	   tGr.plotDots(((CapGraph)graph).getParametersString());
           }
           tGr = null;
       }
       writer.close();
    }
    
    private static int countMultipleConts(HashMap<GraphNode, Integer> mCounter) {
    	int counter = 0;
    	for (GraphNode gNode : mCounter.keySet()) {
    		if (mCounter.get(gNode) > 1) {
    			counter++;
    		}
    	}
    	return counter;
    }
    
    @SuppressWarnings("unused")
	private static void neighborsDistribution(CapGraph gr) throws FileNotFoundException, UnsupportedEncodingException {
    	// Creates a text file with distribution node ~ No of neighbors
    	HashMap<Integer, Integer> nDistr = new HashMap<Integer, Integer>();
    	for (int node : gr.getNodesKeySet()) {
    		int nQuantity = gr.getNeighbors(node).size();
    		if (nDistr.containsKey(nQuantity)) {
    			nDistr.put(nQuantity, nDistr.get(nQuantity) + 1);
    		}
    		else {
    			nDistr.put(nQuantity, 1);
    		}
    	}
        PrintWriter writer = new PrintWriter("nneighbdistr.txt", "UTF-8");
        writer.println("Neighbors distribution for UCSD campus graph");
        writer.println("No of neighbors | No of nodes");
        for (int quan : nDistr.keySet()) {
        	writer.println(quan + ", " + nDistr.get(quan));
        }
        writer.close();
    }
    
    private static int randomNode(CapGraph gr) {
    	// returns No of random Graph node
    	Set<Integer> kSet = gr.getNodesKeySet();
    	Random rnd = new Random();
    	int rNum = rnd.nextInt(kSet.size());
    	int counter = 0;
    	for (int key : kSet) {
    		counter++;
    		if (counter >= rNum) {
    			return key;
    		}
    	}
    	return 0; // never rich this line
    }
}
